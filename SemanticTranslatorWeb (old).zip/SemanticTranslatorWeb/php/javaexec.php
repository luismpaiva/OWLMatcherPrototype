<?php
	exec("java -jar ../java/HelloJavaPHP.jar 1", $output);
	print_r($output);
	echo '</br>';
	echo $output[0];
	echo '</br>';
	echo $output[1];
	echo '</br>';
	var_dump($output);
?>