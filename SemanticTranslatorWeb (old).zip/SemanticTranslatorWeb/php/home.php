<?php
$consumerstr = "consumer";
$providerstr = "provider";
?>
<head>
	<title>Semantic Translator</title>
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
	<link rel="icon" href="../images/favicon.ico" type="image/x-icon">	
	<link rel="stylesheet" type="text/css" href="../lib/bootstrap-3.3.6/css/bootstrap.min.css">
 	<link rel="stylesheet" type="text/css" href="../css/main.css"> 
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="../lib/bootstrap-3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
	<?php echo '<p>Semantic Translator</p>'; ?>
	<div id="inputarea" style="width:43%;">
		<div id="<?php echo $providerstr;?>_box" style="display:inline-block; padding: 0 2%; width:49.5%;">
			<form id="loginform" class="form-inline" name="providerxsd" action="php/login.php" method="post" accept-charset="utf-8">
			<textarea name="'.$providerstr.'area" class="form-control" rows="4" cols="50" style="width:100%" >Insert <?php echo $providerstr ?> XSD text here!</textarea>	<br/>
		    <input type="password" class="form-control " style="width:100%"  name="password" placeholder="&lt;choose XSD file for provider&gt;" required /><br/>
			<button type="submit" class="btn btn-info " style="width:100%" ><?php echo ucwords($providerstr) ?> XSD</button>
			</form>
		</div>
		<div id="<?php echo $consumerstr;?>_box" style="display:inline-block; padding: 0 2%; width:49.5%;">
			<form id="loginform" class="form-inline" name="providerxsd" action="php/login.php" method="post" accept-charset="utf-8">
			  	<textarea name="'.$providerstr.'area" class="form-control" rows="4" cols="50" style="width:100%" >Insert <?php echo $consumerstr?> XSD text here!</textarea>	<br/>
			    <input type="password" class="form-control" style="width:100%"  name="password" placeholder="&lt;choose XSD file for <?php echo $consumerstr?>&gt;" required /><br/>
			  	<button type="submit" class="btn btn-info" style="width:100%" ><?php echo ucwords($consumerstr) ?> XSD</button>
		  	</form>
		</div>
		
		<form id="loginform" class="form-inline" name="providerxsd" action="php/login.php" method="post" accept-charset="utf-8">
			<button type="submit" class="btn btn-info" style="margin: 0 0 0 2%; width:95.5%" align="center"><?php echo 'Translate';	?></button>
		</form>
	</div>
</body>
</html>
	

