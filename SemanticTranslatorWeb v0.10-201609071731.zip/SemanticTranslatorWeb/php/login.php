<?php 
	echo "Username is: " . $_POST['username'] ."</br>";
	echo "Password is: " . $_POST['password'] ."</br>";
?>