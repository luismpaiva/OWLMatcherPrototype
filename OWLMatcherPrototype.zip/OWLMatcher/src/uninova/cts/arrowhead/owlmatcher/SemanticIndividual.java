package uninova.cts.arrowhead.owlmatcher;

import uninova.cts.arrowhead.owlmatcher.semanticelements.SemanticElement;
import uninova.cts.arrowhead.owlmatcher.semanticelements.SemanticElementType;

public class SemanticIndividual extends SemanticElement {
	

	public SemanticIndividual() {
		super(SemanticElementType.INDIVIDUAL);
		// TODO Auto-generated constructor stub
	}


}
