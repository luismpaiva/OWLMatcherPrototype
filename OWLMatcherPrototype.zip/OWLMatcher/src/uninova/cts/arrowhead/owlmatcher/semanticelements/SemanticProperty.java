package uninova.cts.arrowhead.owlmatcher.semanticelements;

public class SemanticProperty extends SemanticElement {

	public SemanticProperty() {
		super(SemanticElementType.PROPERTY);
	}

}
