package uninova.cts.arrowhead.owlmatcher.semanticelements;

public enum SemanticElementType {
	CONCEPT,
	PROPERTY,
	INDIVIDUAL
}
