package uninova.cts.arrowhead.owlmatcher.translations.xsltelements;

import java.util.List;

import org.jdom2.Content;
import org.jdom2.DocType;
import org.jdom2.Document;
import org.jdom2.Element;

public class XSLTDocument extends Document {

	public XSLTDocument() {
		super();
		// TODO Auto-generated constructor stub
	}

	public XSLTDocument(Element rootElement) {
		super(rootElement);
		// TODO Auto-generated constructor stub
	}

	public XSLTDocument(List<? extends Content> content) {
		super(content);
		// TODO Auto-generated constructor stub
	}

	public XSLTDocument(Element rootElement, DocType docType) {
		super(rootElement, docType);
		// TODO Auto-generated constructor stub
	}

	public XSLTDocument(Element rootElement, DocType docType, String baseURI) {
		super(rootElement, docType, baseURI);
		// TODO Auto-generated constructor stub
	}

}
