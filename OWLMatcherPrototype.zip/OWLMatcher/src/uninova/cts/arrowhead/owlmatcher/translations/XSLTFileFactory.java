package uninova.cts.arrowhead.owlmatcher.translations;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.jdom2.Document;
import org.jdom2.output.Format;
import org.jdom2.output.XMLOutputter;

public class XSLTFileFactory {


	private String _fileName = "";
	private String _fileLocation = "";
	private String _fileExtension = ".xslt";
	
    private FileOutputStream fis = null;
    private PrintStream out = null;
    private File file = null;
    
	public XSLTFileFactory() {
	}
	
	public XSLTFileFactory(String location, String filename) {
		if ( location.endsWith("/") || location.endsWith("\\") ) {
			this._fileLocation = location;
		} else {
			if (location.contains("\\")){
				this._fileLocation = location+"\\";
			}
			else if (location.contains("/")){
				this._fileLocation = location+"/";
			} else {
				this._fileLocation = location;
			}
			
		}
//		this._fileLocation = location;
		this._fileName = filename;
	}
	
	
	public void saveToFile(String msg){
		this.openFile(_fileLocation+_fileName+_fileExtension, true);

		this.writeToFile(msg);
		this.closeFile();
	}
	
	public void saveToFile(String msg, String fileName){
		this.openFile(_fileLocation+fileName+_fileExtension, true);
		this.writeToFile(msg);
		this.closeFile();
	}	
	
	public void saveToFile(Document xmlDoc, String fileName, boolean append){
		System.out.println("Saving file <"+fileName+_fileExtension+"> to <"+_fileLocation+">");
		this.openFile(_fileLocation+fileName+_fileExtension, append);
		this.writeToFile(xmlDoc);
		this.closeFile();
	}


	private void writeToFile(String msg){
		this.out.println(msg);
	}


	private void writeToFile(Document xmlDoc){
		//JDOM document is ready now, lets write it to file now
	    XMLOutputter xmlOutputter = new XMLOutputter(Format.getPrettyFormat());
	    try {
			xmlOutputter.output(xmlDoc, this.out);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

    private void openFile(String fileName, boolean append){
        
    	if ( (file == null) || (!file.getPath().equals(fileName)) )
    		file = new File(fileName);
    
        this.fis = null;
        try {
        	if (file.exists())
        		this.fis = new FileOutputStream(file, append);
        	else
        		this.fis = new FileOutputStream(file);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(XSLTFileFactory.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        this.out = new PrintStream(this.fis);
    };
    
    private void closeFile() {
        try {
             this.out.close();
             this.fis.close();
         } catch (IOException ex) {
             Logger.getLogger(XSLTFileFactory.class.getName()).log(Level.SEVERE, null, ex);
         }
     };
    

	public static void main(String[] args) {
		
		XSLTFileFactory ls = new XSLTFileFactory("","xpto");
		
		// ls._logFolder = "C:\\Users\\Luis\\Documents\\Uninova\\ProaSense\\workspace\\logs\\";
		// ls._logFileName = "logTest.log";
		
		ls.saveToFile("Hello");
		
		ls.saveToFile("Hello", "xpto2");
		
		ls.saveToFile("Hello");
	}
}
