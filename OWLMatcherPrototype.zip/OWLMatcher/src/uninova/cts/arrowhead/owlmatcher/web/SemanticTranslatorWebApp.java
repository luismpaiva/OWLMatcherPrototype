package uninova.cts.arrowhead.owlmatcher.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

import uninova.cts.arrowhead.owlmatcher.SemanticEngine;

public class SemanticTranslatorWebApp {

	public SemanticTranslatorWebApp() {
		// TODO Auto-generated constructor stub
	}

	private ArrayList<String> readFile(String filename)
	{
	  ArrayList<String> records = new ArrayList<String>();
	  try
	  {
	    BufferedReader reader = new BufferedReader(new FileReader(filename));
	    String line;
	    while ((line = reader.readLine()) != null)
	    {
	      records.add(line);
	    }
	    reader.close();
	    return records;
	  }
	  catch (Exception e)
	  {
	    System.err.format("Exception occurred trying to read '%s'.", filename);
	    e.printStackTrace();
	    return null;
	  }
	}

	public static void main(String[] args) {

		String s = "tempsensor.owl";
		SemanticEngine semEngine = new SemanticEngine(s);
		
		semEngine.setProviderSchemaLocation(args[0]);
		semEngine.setConsumerSchemaLocation(args[1]);

		// args will receive two filelocations:
		// 1 - provider xsd file
		// 2 - consumer xsd file
		System.out.println("Arguments received: ");
		for (int i=0; i<args.length; i++) {
			System.out.println("arg["+i+"]: "+args[i].toString());
		}
		System.out.println("Arguments received ok!");
		
		semEngine.printSemanticAnnotatedElements(args[0], args[1], s);
		
////		String filenameLocation = args[0];
////		String filenameLocation = "C:\\Users\\Luis\\Desktop\\Institutions.txt";
//		String filenameLocation = "C:\\Users\\Luis\\Documents\\Uninova\\Arrowhead\\OWLMatcherPrototype\\OWLMatcher\\Xsd_Xml\\provider.xsd";
//		SemanticTranslatorWebApp hjphp = new SemanticTranslatorWebApp();
//		
//		File fileA  = new File(filenameLocation);
//		ArrayList<String> fileContents = hjphp.readFile(filenameLocation);
////		System.out.println("Hello World PHP - arg0: " + args[0]);
//		System.out.println("Second output! \n other line");
////		fileContents.toString();
//		System.out.println("File contents: ");
//		String fileContentsString = "";// "<![CDATA[";
//		for (int i=0; i<fileContents.size(); i++){
//			String tmp = fileContents.get(i);
////			fileContentsString = fileContentsString.concat("<![CDATA[");
//			fileContentsString = fileContentsString.concat(fileContents.get(i));
//			fileContentsString = fileContentsString.concat("\n");
////			fileContentsString = fileContentsString.concat("]]>");
//		}
////		fileContentsString = fileContentsString.concat("]]>");
//		System.out.print(fileContentsString);
//		System.out.println();
	}

}
