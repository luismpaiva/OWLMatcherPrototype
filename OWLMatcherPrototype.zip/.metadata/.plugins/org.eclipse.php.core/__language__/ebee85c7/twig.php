<?php

// Start of twig v.1.16.0

/**
 * @param template
 * @param object
 * @param item
 * @param arguments
 * @param type
 * @param isDefinedTest
 */
function twig_template_get_attributes ($template, $object, $item, $arguments, $type, $isDefinedTest) {}

// End of twig v.1.16.0
