<?php
$consumerstr = "consumer";
$providerstr = "provider";
?>
<head>
	<title>Semantic Translator</title>
	<link rel="shortcut icon" href="../images/favicon.ico" type="image/x-icon">
	<link rel="icon" href="../images/favicon.ico" type="image/x-icon">	
	<link rel="stylesheet" type="text/css" href="../lib/bootstrap-3.3.6/css/bootstrap.min.css">
 	<link rel="stylesheet" type="text/css" href="../css/main.css"> 
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
	<script src="../lib/bootstrap-3.3.6/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="panel panel-default">
	  <div class="panel-heading">
		 <div class="btn-group">
		  <button type="button" onclick="document.location='home.php'" class="btn btn-primary">New Translator</button>
		  <button onclick="document.location='downloadfile.php'" class="btn btn-default disabled">Download XSLT</button>
		  <button type="button" class="btn btn-default disabled">Translate XML</button>
		</div>	  
	  </div>
  	</div>

	<div style="margin: 0 0">
		<div style="text-align: center; margin: 0;"><p style="padding: 0; margin: 1% 0;">Semantic Translator</p></div>
		<div style="background-color: #f5f5f5; margin: 0; padding:0;">
			<form id="loginform" class="form-inline" name="providerxsd" action="../php/javaexec.php" method="post" accept-charset="utf-8" enctype="multipart/form-data">
			<div id="inputarea" style="width:65%; margin:auto; padding:1% 0">
				<div id="<?php echo $providerstr;?>_box" style="display:inline-block; padding: 0 2%; width:49.5%;">
					<textarea name="<?php echo $providerstr;?>_area" class="form-control" rows="4" cols="50" style="width:100%" >Select <?php echo $providerstr ?> XSD below!</textarea>	<br/>
				    <!--  <input type="file" class="form-control " style="width:100%"  name="password" placeholder="&lt;choose XSD file for provider&gt;" /><br/>  -->
					<!--  <button type="submit" class="btn btn-info " style="width:100%" ><?php // echo ucwords($providerstr) ?> XSD</button>  -->
				    <label class="btn btn-info btn-file" style="width:100%" >
				        <?php echo ucwords($providerstr) ?> XSD 
				        <input name="<?php echo $providerstr;?>file" type="file" style="width:100% /*display: none;*/">
				    </label>
				</div>
				<div id="<?php echo $consumerstr;?>_box" style="display:inline-block; padding: 0 2%; width:49.5%;">
				  	<textarea name="<?php echo $consumerstr;?>_area" class="form-control" rows="4" cols="50" style="width:100%" >Select <?php echo $consumerstr?> XSD below!</textarea>	<br/>
				    <!-- <input type="file" class="form-control" style="width:100%"  name="password" placeholder="&lt;choose XSD file for <?php // echo $consumerstr?>&gt;" /><br/>  -->
				    <label class="btn btn-info btn-file" style="width:100%" >
				        <?php echo ucwords($consumerstr) ?> XSD 
				        <input name="<?php echo $consumerstr;?>file" type="file" style="width:100% /*display: none;*/">
				    </label>
				</div>
				
				<div style="padding: 1% 0 0 0;">
					<button type="submit" class="btn btn-info" style="margin: 0 0 0 2%; width:95.5%" align="center"><?php echo 'Translate';	?></button>
				</div>
					
				</div>
			</form>
		</div>
	</div>
	
	
</body>
</html>
	

