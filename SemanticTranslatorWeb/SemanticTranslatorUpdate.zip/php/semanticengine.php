<?php
// 	class SemanticMessage {
		
// 		function getMessage(){
// // 			$url = $file_name;
// 			$url = "/msg_files/msg_id2_c10.msg";
// 			$fields = array(
// 					'__VIEWSTATE'=>urlencode($state),
// 					'__EVENTVALIDATION'=>urlencode($valid),
// 					'btnSubmit'=>urlencode('Submit')
// 			);
			
// 			//url-ify the data for the POST
// 			foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
// 			$fields_string = rtrim($fields_string,'&');
			
// 			//open connection
// 			$ch = curl_init();
			
// 			//set the url, number of POST vars, POST data
// 			curl_setopt($ch,CURLOPT_URL,$url);
// 			curl_setopt($ch,CURLOPT_POST,count($fields));
// 			curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);
			
// 			//execute post
// 			$result = curl_exec($ch);
// 			print $result;
// 		}
		
// 	}

//     print_r($_POST);
//     echo $_POST['provider_id']."\n";
    $provider_id = $_POST['provider_id'];
    $provider_msg = $_POST['provider_msg'];
    $filelocation = '/var/www/SemanticTranslatorWeb/msgfiles/';
    $filelocation = "C:\\Users\\Luis\\Documents\\Uninova\\Arrowhead\\OWLMatcherPrototype\\SemanticTranslatorWeb\\msgfiles\\";
    
    $filename = $filelocation.'msg_id'.$provider_id.'_c'.$provider_msg.'.msg';
//     $filename = $filelocation.'msg_id2'.'_c10'.'.msg';
//     echo $filename;
    echo file_get_contents($filename);
//     echo 'Hello World-'.$provider_id.'\n';
// 	$x = 1;
// 	echo 'Hello World'."\n";
// 	echo $x;
?>


 <?php 
// http://stackoverflow.com/questions/5647461/how-do-i-send-a-post-request-with-php
// $url = $file_name;
// $fields = array(
//             '__VIEWSTATE'=>urlencode($state),
//             '__EVENTVALIDATION'=>urlencode($valid),
//             'btnSubmit'=>urlencode('Submit')
//         );

// //url-ify the data for the POST
// foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
// $fields_string = rtrim($fields_string,'&');

// //open connection
// $ch = curl_init();

// //set the url, number of POST vars, POST data
// curl_setopt($ch,CURLOPT_URL,$url);
// curl_setopt($ch,CURLOPT_POST,count($fields));
// curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);

// //execute post
// $result = curl_exec($ch);
// print $result;
// 
?>